module.exports = {
  email: "EMAIL",
  password: "PASSWORD",
  NEXMO_API_KEY: "API_KEY",
  NEXMO_API_SECRET: "SECRET_KEY",
  NEXMO_FROM_NUMBER: "NUMBER",
  MongoURI: `ENTER_MONGOURI`
}
